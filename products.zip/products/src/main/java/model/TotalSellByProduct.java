package model;

public class TotalSellByProduct {
	int productCode;
	String productName;
	int unitPrice;
	int quantity;
	int amount;
	String date;
	
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "TotalSellByProduct [productCode=" + productCode + ", productName=" + productName + ", unitPrice="
				+ unitPrice + ", quantity=" + quantity + ", amount=" + amount + ", date=" + date + "]";
	}
	
	
}
